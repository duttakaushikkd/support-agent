"""Batch evaluation entry point."""
